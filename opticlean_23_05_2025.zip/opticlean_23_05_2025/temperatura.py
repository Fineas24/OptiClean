import os
import glob
import time

# Inițializare 1-Wire
os.system('modprobe w1-gpio')
os.system('modprobe w1-therm')

# Căutare fișier senzor
base_dir = '/sys/bus/w1/devices/'
device_folder = glob.glob(base_dir + '28*')[0]  # 28* e prefixul senzorului
device_file = device_folder + '/w1_slave'

def citeste_temperatura_raw():
    with open(device_file, 'r') as f:
        return f.readlines()

def citeste_temperatura():
    linii = citeste_temperatura_raw()
    while linii[0].strip()[-3:] != 'YES':
        time.sleep(0.2)
        linii = citeste_temperatura_raw()
    
    temp_poz = linii[1].find('t=')
    if temp_poz != -1:
        temp_string = linii[1][temp_poz + 2:]
        temperatura_c = float(temp_string) / 1000.0
        return temperatura_c

# Afișare temperatură
temp = citeste_temperatura()
print(f"Temperatura este: {temp:.2f}°C")
