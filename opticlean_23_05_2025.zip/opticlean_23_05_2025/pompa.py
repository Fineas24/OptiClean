#!/usr/bin/env python3

import os
os.chdir("/tmp")  # Change working directory to /tmp to avoid permission issues

import RPi.GPIO as GPIO
import sys
import time

# Pin configuration
POMPA_PIN = 23

# Setup GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(POMPA_PIN, GPIO.OUT)
#GPIO.output(POMPA_PIN, GPIO.HIGH)

# Check command line arguments
if len(sys.argv) != 2:
    print("Usage: python3 pompa.py [on|off]")
    GPIO.cleanup()
    sys.exit(1)

command = sys.argv[1].lower()

try:
    if command == "on":
        GPIO.output(POMPA_PIN, GPIO.LOW)
        print("Pompa ON (GPIO 23 set HIGH)")

    elif command == "off":
        GPIO.output(POMPA_PIN, GPIO.HIGH)
        
        print("Pompa OFF (GPIO 23 set LOW)")

    else:
        print("Invalid command. Use 'on' or 'off'.")

except Exception as e:
    print(f"Error: {e}")

#finally:
    #GPIO.cleanup()
