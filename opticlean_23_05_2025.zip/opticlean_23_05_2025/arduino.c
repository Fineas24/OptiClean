#include <AccelStepper.h>

// ------------------ CONFIGURARE ------------------
float speedX = 1000;  // Viteza X (pasi/secunda)
float speedY = 1000;  // Viteza Y (pasi/secunda)
float speedZ = 250;  // Viteza Z (pasi/secunda)
float speedA = 1000;  // Viteza A (pasi/secunda)
// -------------------------------------------------

// Motoare
AccelStepper stepperX(AccelStepper::DRIVER, 2, 5);
AccelStepper stepperY(AccelStepper::DRIVER, 3, 6);
AccelStepper stepperZ(AccelStepper::DRIVER, 4, 7);
AccelStepper stepperA(AccelStepper::DRIVER, 12, 13);

// Control XY
bool startY = false;
unsigned long startTime = 0;
unsigned long delayY_us = 100;

int switch_xy = 9;
int switch_z = 10;
volatile int val_switch_xy;
volatile int val_switch_z;

String inputString = "";
bool commandActiveXY = false;

void setup() {
  Serial.begin(9600);
  pinMode(switch_xy, INPUT);
  pinMode(switch_z, INPUT);

  stepperX.setMaxSpeed(speedX);
  stepperX.setAcceleration(500);

  stepperY.setMaxSpeed(speedY);
  stepperY.setAcceleration(500);

  stepperZ.setMaxSpeed(speedZ);
  stepperZ.setAcceleration(500);

  stepperA.setMaxSpeed(speedA);
  stepperA.setAcceleration(500);

  stepperX.setCurrentPosition(0);
  stepperY.setCurrentPosition(0);
  stepperZ.setCurrentPosition(0);
  stepperA.setCurrentPosition(0);

  Serial.println("Comenzi:");
  Serial.println("XY<nr> -> misca X si Y cu delay (ex: XY100, XY-200)");
  Serial.println("Z<nr>  -> misca Z de 5 ori cu delay 500ms");
  Serial.println("A<nr>  -> misca A de 5 ori cu delay 500ms");
  Serial.println("D<delay_us> -> seteaza delay Y (ex: D1000)");
}

void loop() {
  if (Serial.available() > 0) {
    char inChar = (char)Serial.read();
    if (inChar == '\n' || inChar == '\r') {
      processInput(inputString);
      inputString = "";
    } else {
      inputString += inChar;
    }
  }

  stepperX.run();
  stepperY.run();
  stepperZ.run();
  stepperA.run();

  if (commandActiveXY && !startY && (micros() - startTime >= delayY_us)) {
    startY = true;
    Serial.println("Motor Y pornit dupa delay (μs)");
  }
}

void moveStepperMultiple(AccelStepper &stepper, long steps, int times) {
  for (int i = 0; i < times; i++) {
    long target = stepper.currentPosition() + steps;
    stepper.moveTo(target);

    while (stepper.distanceToGo() != 0) {
      stepper.run();
    }

    Serial.print("Executie ");
    Serial.print(i + 1);
    Serial.print(" din ");
    Serial.println(times);

    delay(500);  // 0.5 secunde
  }
}

void home_xy() {
  stepperX.setMaxSpeed(400);
  stepperY.setMaxSpeed(400);
  stepperX.setAcceleration(100);
  stepperY.setAcceleration(100);
  stepperX.moveTo(10000);  // Move in negative direction indefinitely
  stepperY.moveTo(-10000);  // Move in negative direction indefinitely

  // Move until switch is triggered
  while (digitalRead(switch_xy) == LOW) {
  stepperX.run();
  stepperY.run();  // MUST be called to make the motor move
  }

  // Stop movement smoothly
  stepperX.stop();
  stepperY.stop();
  Serial.print("gata 1 Home_XY ");
 /*/ while (stepperX.isRunning()) {
    stepperX.stop();  // Finish decelerating
    stepperY.stop();
  }*/
  Serial.print("gata 2 Home_XY ");

 // delay(2000);

  stepperX.setCurrentPosition(0);  // Set this position as 'home'
  stepperY.setCurrentPosition(0);  // Set this position as 'home'
  stepperX.moveTo(-50);            // Optional: move a bit away from switch
  stepperY.moveTo(50);            // Optional: move a bit away from switch
  while (stepperX.distanceToGo() != 0) {
    stepperX.run();
  stepperY.run();
  }
Serial.print("gata Home_XY ");

}


void home_z() {
  stepperZ.setMaxSpeed(400);
  stepperZ.setAcceleration(100);
  stepperZ.moveTo(-10000);  // Move in negative direction indefinitely

  val_switch_z=digitalRead(switch_z);
 Serial.print("val_switch_z=");
 Serial.println(val_switch_z);

long pos = stepperZ.currentPosition();
 Serial.print("poz0=");
 Serial.println(pos);

  // Move until switch is triggered
  while (digitalRead(switch_z) == LOW) {
  stepperZ.run();
  }
Serial.print("gata 0 Home_Z ");
  // Stop movement smoothly
  stepperZ.stop();
  Serial.print("gata 1 Home_Z ");

 //delay(1000);

  stepperZ.setCurrentPosition(0);  // Set this position as 'home'
  //stepperZ.moveTo(5);            // Optional: move a bit away from switch
  while (stepperZ.distanceToGo() != 0) {
    stepperZ.run();
  }
  pos = stepperZ.currentPosition();
 Serial.print("poz=");
 Serial.println(pos);
Serial.print("gata Home_Z ");

}

void processInput(String command) {
  command.trim();
  if (command.length() == 0) return;

  command.toUpperCase();

  if (command.startsWith("HOMEXY")) {
    Serial.print("Home_XY ");
    home_xy();
    return;
  }  
  if (command.startsWith("HOMEZ")) {
    Serial.print("Home_Z ");
    home_z();
    return;
  }  
  
  if (command.charAt(0) == 'D') {
    delayY_us = command.substring(1).toInt();
    Serial.print("Delay setat la: ");
    Serial.print(delayY_us);
    Serial.println(" μs");
    return;
  }



  if (command.startsWith("XY")) {
    long moveSteps = command.substring(2).toInt();
    long targetX = stepperX.currentPosition() + moveSteps;
    long targetY = stepperY.currentPosition() - moveSteps;
    stepperX.moveTo(targetX);
    stepperY.moveTo(targetY);
    startTime = micros();
    startY = false;
    commandActiveXY = true;

    Serial.print("XY comanda: ");
    Serial.println(moveSteps);
    Serial.print("X -> ");
    Serial.print(targetX);
    Serial.print(" | Y (delay ");
    Serial.print(delayY_us);
    Serial.print(" μs) -> ");
    Serial.println(targetY);
    return;
  }

  if (command.startsWith("Z")) {
    long moveSteps = command.substring(1).toInt();
    Serial.print("Z comanda repetata de 5 ori: ");
    Serial.println(moveSteps);
    moveStepperMultiple(stepperZ, moveSteps, 1);
    return;
  }

  if (command.startsWith("A")) {
    long moveSteps = command.substring(1).toInt();
    Serial.print("A comanda repetata de 5 ori: ");
    Serial.println(moveSteps);
    moveStepperMultiple(stepperA, moveSteps, 1);
    return;
  }

  Serial.println("Comanda necunoscuta. Foloseste XY<nr>, Z<nr>, A<nr> sau D<delay_us>.");
}