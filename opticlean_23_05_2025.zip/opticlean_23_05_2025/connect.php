<?php
$servername = "localhost";
$username = "10a"; // Change this to your DB username
$password = "raspberry";     // Change this to your DB password
$dbname = "opticlean";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
