<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Opticlean</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    </head>
<body>
    <div class="video-container">
    <img src="http://192.168.6.212:8080/?action=stream" alt="Live Camera Feed3">
</div>


</body>
</html>