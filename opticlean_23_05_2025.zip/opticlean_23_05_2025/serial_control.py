# serial_control.py
import serial
import sys
import time

# Replace with your actual serial port
#SERIAL_PORT = "/dev/ttyACM0"
SERIAL_PORT = "/dev/serial/by-id/usb-Arduino__www.arduino.cc__0043_34330303436351F01270-if00"
BAUD_RATE = 9600

if len(sys.argv) < 2:
    print("No command provided")
    sys.exit(1)

command = sys.argv[1]

try:
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
    time.sleep(2)  # Wait for Arduino to reset (required)
    ser.write((command + "\n").encode())
    ser.close()
    print(f"Sent: {command}")
except Exception as e:
    print(f"Error: {e}")
