# gpio_control.py

import os
os.chdir("/tmp")  # Change working directory to /tmp to avoid permission issues

import RPi.GPIO as GPIO
import sys
import time

GPIO.setmode(GPIO.BCM)

# Map commands to GPIO pins
pin_map = {
    "spray": 17,
    "uscare": 18,
    "start_ultrasunete": 27,
    "start_temp": 22,
    "sus": 23,
    "jos": 24,
    "start_auto": 25,
    "stop_auto": 10
}

if len(sys.argv) < 2:
    print("No command provided")
    sys.exit(1)

command = sys.argv[1]

if command not in pin_map:
    print(f"Invalid command: {command}")
    sys.exit(1)

pin = pin_map[command]

# Set pin as output and trigger it
GPIO.setup(pin, GPIO.OUT)
GPIO.output(pin, GPIO.LOW)
time.sleep(1)
GPIO.output(pin, GPIO.HIGH)
GPIO.cleanup()
