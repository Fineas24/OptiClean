# serial_control.py
import serial
import sys
import time
import subprocess
import RPi.GPIO as GPIO

# Replace with your actual serial port
#SERIAL_PORT = "/dev/ttyACM0"
SERIAL_PORT = "/dev/serial/by-id/usb-Arduino__www.arduino.cc__0043_34330303436351F01270-if00"
BAUD_RATE = 9600

pin_uscare=18

GPIO.setmode(GPIO.BCM)
GPIO.setup(pin_uscare, GPIO.OUT)
GPIO.output(pin_uscare, GPIO.HIGH)


try:
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
    time.sleep(2)  # Wait for Arduino to reset (required)

    #pornire temperatura
    # Run the command as if from terminal
    subprocess.run(['python', 'gpio_control.py', 'start_temp'])    
    time.sleep(0.5)
    command = "start temp."
    print(f"Sent: {command}")

    command = "homexy"
    ser.write((command + "\n").encode())
    time.sleep(10)
    print(f"Sent: {command}")

    command = "homez"
    ser.write((command + "\n").encode())
    time.sleep(7)
    print(f"Sent: {command}")

    command = "Z65"
    ser.write((command + "\n").encode())
    time.sleep(5)
    print(f"Sent: {command}")

    #coboara pt spray
    command = "XY-150"
    ser.write((command + "\n").encode())
    time.sleep(5)
    print(f"Sent: {command}")

    #spray 1
    command = "A300"
    ser.write((command + "\n").encode())
    time.sleep(5)
    print(f"Sent: {command}")

    command = "Z10"
    ser.write((command + "\n").encode())
    time.sleep(5)
    print(f"Sent: {command}")

    #spray 2
    command = "A300"
    ser.write((command + "\n").encode())
    time.sleep(5)
    print(f"Sent: {command}")


    #homez
    command = "homez"
    ser.write((command + "\n").encode())
    time.sleep(5)
    print(f"Sent: {command}")

    #coboara pt ultrasunete
    command = "XY-400"
    ser.write((command + "\n").encode())
    time.sleep(5)
    print(f"Sent: {command}")

    #pornire ultrasunete
    # Run the command as if from terminal
    subprocess.run(['python', 'gpio_control.py', 'start_ultrasunete'])    
    command = "start utrasunete"
    print(f"Sent: {command}")
    time.sleep(10)

    #oprire ultrasunete
    # Run the command as if from terminal
    subprocess.run(['python', 'gpio_control.py', 'start_ultrasunete'])    
    command = "stop utrasunete"
    print(f"Sent: {command}")
    

    #urca pt uscare
    command = "XY650"
    ser.write((command + "\n").encode())
    time.sleep(5)
    print(f"Sent: {command}")

     # scutura
    for i in range(6):
        command = "Z5"
        ser.write((command + "\n").encode())
        time.sleep(1)
        command = "Z-5"
        ser.write((command + "\n").encode())
        print(f"Step {i+1}/10 - Sent: {command}")

       
    #stop temperatura
    # Run the command as if from terminal
    subprocess.run(['python', 'gpio_control.py', 'start_temp'])    
    time.sleep(0.5)
    command = "stop temp."
    print(f"Sent: {command}")

    #invarte la uscare
    command = "Z100"
    ser.write((command + "\n").encode())
    time.sleep(5)
    print(f"Sent: {command}")

    #pornire uscator
    # Run the command as if from terminal
    #subprocess.run(['python', 'gpio_control.py', 'uscare'])    
    GPIO.output(pin_uscare, GPIO.LOW)
    command = "uscare"
    print(f"Sent: {command}")

    
     # Învârte la uscare timp de 10 pași
    for i in range(12):
        command = "Z10"
        ser.write((command + "\n").encode())
        command = "Z-10"
        ser.write((command + "\n").encode())
        time.sleep(1)
        print(f"Step {i+1}/10 - Sent: {command}")
    
    time.sleep(5)
    #stop foehn
    GPIO.output(pin_uscare, GPIO.HIGH)

    command = "homez"
    ser.write((command + "\n").encode())
    time.sleep(10)
    print(f"Sent: {command}")

    command = "homexy"
    ser.write((command + "\n").encode())
    time.sleep(10)
    print(f"Sent: {command}")
    
    ser.close()
    print(f"Sent gata: {command}")
except Exception as e:
    print(f"Error: {e}")
