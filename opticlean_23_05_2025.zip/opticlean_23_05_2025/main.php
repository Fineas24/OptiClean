<?php
include('connect.php');
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

// Fetch the IP from the 'setari' table
$sql = "SELECT set_value FROM setari WHERE set_name = 'ip' LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Get the IP address
    $row = $result->fetch_assoc();
    $ip_address = $row['set_value'];
} else {
    // Default value if no record found
    $ip_address = 'localhost';
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Opticlean</title>
    <link rel="stylesheet" type="text/css" href="style.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
        }

        .header {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            background-color: #f1f1f1;
            padding: 10px 20px;
            border-bottom: 1px solid #ccc;
        }

        .header span {
            margin-right: 20px;
        }

        .main-content {
            display: flex;
            height: calc(100vh - 50px);
        }

        .sidebar {
            width: 300px;
            background-color: #eaeaea;
            padding: 20px;
        }

        .button-group {
            margin-bottom: 30px;
        }

        .button-group h3 {
            margin-bottom: 10px;
        }

        .button-row {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .button-row button {
            padding: 10px 15px;
            font-size: 14px;
            cursor: pointer;
        }
        .video-container {
        flex-grow: 1;
        background-color: #fff;
        display: flex;
        justify-content: center;
        align-items: center;
        }
        .video-container img {
            width: 100%;
            height: auto;
        }

        .video-container {
        position: absolute; /* Allows precise placement */
        top: 80px;  /* Adjust vertical position */
        left: 600px; /* Adjust horizontal position */
        width: 780px; /* Set the width */
        height: 600px; /* Set the height */
        background-color: #fff; /* Ensure white background */
        display: flex;
        justify-content: center;
        align-items: center;
    }

        .video-container img {
        width: 100%; /* Make image fit container */
        height: auto;
        border: 2px solid #000; /* Optional border */
        }   

    </style>
</head>
<body>
<div class="header">
    <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
    <span>You have successfully logged in.</span>
    <a href="logout.php">Logout</a>
</div>
<div class="main-content">
    <div class="sidebar">
        <div id="tempDisplay" style="font-size: 18px; margin-top: 20px;">Citire temperatura...</div>
        <div class="button-group">
            <h3>Manual</h3>
            <div class="button-row">
            <form method="post" action="serial.php" style="display:inline;">
                <input type="hidden" name="value" value="A300">
                <button type="submit">Spray</button>
            </form>

            <form method="post" action="control.php" style="display:inline;">
                <input type="hidden" name="command" value="uscare">
                <button type="submit">Uscare</button>
            </form>

            <form method="post" action="control.php" style="display:inline;">
                <input type="hidden" name="command" value="start_ultrasunete">
                <button type="submit">Start/Stop Ultrasu</button>
            </form>

            <form method="post" action="control.php" style="display:inline;">
                <input type="hidden" name="command" value="start_temp">
                <button type="submit">Start/Stop temp</button>
            </form>

            <!-- sus button -->
            <form method="post" action="serial.php" style="display:inline;">
                <input type="hidden" name="value" value="XY100">
                <button type="submit">Sus</button>
            </form>

            <!-- jos button -->
            <form method="post" action="serial.php" style="display:inline;">
                <input type="hidden" name="value" value="XY-100">
                <button type="submit">Jos</button>
            </form>

            <!-- Spin CW -->
            <form method="post" action="serial.php" style="display:inline;">
                <input type="hidden" name="value" value="Z-40">
                <button type="submit">Spin CW</button>
            </form>

            <!-- Spin CCW -->
            <form method="post" action="serial.php" style="display:inline;">
                <input type="hidden" name="value" value="Z40">
                <button type="submit">Spin CCW</button>
            </form>

            <!-- homexy -->
            <form method="post" action="serial.php" style="display:inline;">
                <input type="hidden" name="value" value="homexy">
                <button type="submit">HomeXY</button>
            </form>
             <!-- homez -->
            <form method="post" action="serial.php" style="display:inline;">
                <input type="hidden" name="value" value="homez">
                <button type="submit">HomeZ</button>
            </form>

            <form method="post" action="control_pompa.php" style="display:inline;">
                <input type="hidden" name="command" value="on">
                <button type="submit">Pompa on</button>
            </form>

            <form method="post" action="control_pompa.php" style="display:inline;">
                <input type="hidden" name="command" value="off">
                <button type="submit">Pompa off</button>
            </form>
                
            </div>
        </div>

        <div class="button-group">
            <h3>Automatic</h3>
            <div class="button-row">
            <form method="post" action="start.php" style="display:inline;">
                <input type="hidden" name="command" value="actiune inceputa">
                <button type="submit">Start</button>
            </form>
            <form method="post" action="stop.php" style="display:inline;">
                <button type="submit">Stop</button>
            </form>
            </div>
        </div>
    </div>
</div>
<div class="video-container">
   <img src="http://<?php echo htmlspecialchars($ip_address); ?>:8080/?action=stream" alt="Live Camera Feed">
</div>

<script>
function updateTemperature() {
    fetch('get_temp.py')
        .then(response => response.json())
        .then(data => {
            if (data.temperature !== null) {
                const tempElement = document.getElementById('tempDisplay');
                tempElement.innerHTML = `Temperatura: ${data.temperature.toFixed(2)} °C`;

                // Change color if temperature is above 50°C
                if (data.temperature > 50) {
                    tempElement.style.color = 'red';
                } else {
                    tempElement.style.color = 'black';
                }
            } else {
                document.getElementById('tempDisplay').innerHTML = `Sensor error.`;
            }
        })
        .catch(error => {
            console.error("Error:", error);
            document.getElementById('tempDisplay').innerHTML = `Failed to read temperature.`;
        });
}

setInterval(updateTemperature, 1000);
updateTemperature();  // initial call
</script>

</body>
</html>
