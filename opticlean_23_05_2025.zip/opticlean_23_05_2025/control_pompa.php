<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['command'])) {
    $command = escapeshellarg($_POST['command']);
    $output = shell_exec("python3 /var/www/html/opticlean/pompa.py $command 2>&1");
    echo "Command executed: $command<br>";
    echo "Output:<br><pre>$output</pre>";
} else {
    echo "No command received.";
}
?>