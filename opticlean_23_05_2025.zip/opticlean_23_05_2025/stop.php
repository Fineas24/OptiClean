<?php

//ps aux | grep auto.py     //pentru a rula in terminal pt a vedea detaliile procesului
$pidFile = '/tmp/auto_pid.txt';

if (file_exists($pidFile)) {
    $pid = trim(file_get_contents($pidFile));

    if (is_numeric($pid)) {
        // Kill the process
        shell_exec("kill $pid");
        // Optional: delete the PID file
        unlink($pidFile);
        echo "auto.py stopped.";
    } else {
        echo "Invalid PID.";
    }
} else {
    echo "PID file not found. Script may not be running.";
}

?>
