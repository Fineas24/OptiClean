<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['value'])) {
    $value = escapeshellarg($_POST['value']);
    $output = shell_exec("python3 /var/www/html/opticlean/serial_control.py $value 2>&1");
    echo "<pre>$output</pre>";
} else {
    echo "No value received.";
}
?>
